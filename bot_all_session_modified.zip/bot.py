import asyncio
import logging
import os
from collections import defaultdict
from pathlib import Path

import asyncpg
import yt_dlp
from pyrogram import Client, filters
from pyrogram.types import MessageEntity
from pytgcalls import PyTgCalls
from pytgcalls import filters as call_filters
from pytgcalls.types import MediaStream, StreamEnded

from config import (
    API_ID,
    API_HASH,
    BOT_TOKEN,
    SESSION_STRING,
    OWNER_ID,
    DATABASE_URL,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
log = logging.getLogger("pro_music_bot")

# Telegram bot: receives commands.
bot = Client(
    "pro_music_bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
)

# User/assistant account: joins the Telegram Voice Chat.
assistant = Client(
    "music_assistant",
    api_id=API_ID,
    api_hash=API_HASH,
    session_string=SESSION_STRING,
)

# PyTgCalls controls the Voice Chat using the assistant account.
calls = PyTgCalls(assistant)

db = None
queues = defaultdict(list)   # chat_id -> queued song dicts
current = {}                 # chat_id -> currently playing song dict
locks = defaultdict(asyncio.Lock)

# /all mention tasks: one running task per group.
mention_tasks = {}
mention_stop_events = {}

DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)

# Optional. Add REQUIRED_GROUP_ID to Codespaces environment variables
# if you want private /start to require membership in one specific group.
REQUIRED_GROUP_ID = os.getenv("REQUIRED_GROUP_ID", "").strip()


async def init_db():
    global db

    db = await asyncpg.create_pool(
        DATABASE_URL,
        min_size=1,
        max_size=10,
    )

    async with db.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                language TEXT DEFAULT 'my'
            )
        """)

        await conn.execute("""
            CREATE TABLE IF NOT EXISTS authorized_users (
                chat_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                PRIMARY KEY (chat_id, user_id)
            )
        """)

    log.info("PostgreSQL database initialized")


async def is_admin_or_owner(client, chat_id: int, user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True

    try:
        member = await client.get_chat_member(chat_id, user_id)
        status = str(member.status).lower()

        return status in {
            "administrator",
            "owner",
            "chatmemberstatus.administrator",
            "chatmemberstatus.owner",
        }
    except Exception:
        return False


async def is_authorized(chat_id: int, user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True

    async with db.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT 1
            FROM authorized_users
            WHERE chat_id=$1 AND user_id=$2
            """,
            chat_id,
            user_id,
        )

    return row is not None


async def can_control(client, chat_id: int, user_id: int) -> bool:
    if await is_admin_or_owner(client, chat_id, user_id):
        return True

    return await is_authorized(chat_id, user_id)


async def required_group_ok(user_id: int) -> bool:
    if not REQUIRED_GROUP_ID:
        return True

    try:
        member = await bot.get_chat_member(
            REQUIRED_GROUP_ID,
            user_id,
        )

        status = str(member.status).lower()

        return status not in {
            "left",
            "kicked",
            "chatmemberstatus.left",
            "chatmemberstatus.banned",
        }

    except Exception:
        return False


async def is_bot_admin(chat_id: int) -> bool:
    """Return True only when the bot itself is an administrator in the group."""
    try:
        me = await bot.get_me()
        member = await bot.get_chat_member(chat_id, me.id)
        status = str(member.status).lower()
        return status in {
            "administrator",
            "owner",
            "chatmemberstatus.administrator",
            "chatmemberstatus.owner",
        }
    except Exception as error:
        log.warning("Bot admin check failed in %s: %s", chat_id, error)
        return False


def _utf16_len(value: str) -> int:
    return len(value.encode("utf-16-le")) // 2


async def send_member_batch(chat_id: int, members: list, prefix: str = "") -> None:
    """Send one 5-member text-mention message using Telegram user IDs."""
    lines = []
    entities = []
    offset = 0

    prefix = (prefix or "").strip()
    if prefix:
        lines.append(prefix)
        offset = _utf16_len(prefix) + 1

    for member in members:
        user = getattr(member, "user", member)
        name = (getattr(user, "first_name", None) or "User").strip()
        last_name = getattr(user, "last_name", None)
        if last_name:
            name = f"{name} {last_name}".strip()

        # Keep the display text compact and safe for Telegram's message limit.
        label = f"👤 {name}"
        start = offset + _utf16_len("👤 ")
        lines.append(label)
        entities.append(
            MessageEntity(
                type="text_mention",
                offset=start,
                length=_utf16_len(name),
                user=user,
            )
        )
        offset += _utf16_len(label) + 1

    if not lines:
        return

    await bot.send_message(
        chat_id,
        "\n".join(lines),
        entities=entities,
    )


async def run_all_mentions(chat_id: int, stop_event: asyncio.Event, prefix: str = "") -> None:
    """Fetch group members through the user session and mention them 5 at a time."""
    batch = []
    sent = 0

    try:
        async for member in assistant.get_chat_members(chat_id):
            if stop_event.is_set():
                break

            user = getattr(member, "user", None)
            if user is None:
                continue
            if getattr(user, "is_deleted", False):
                continue

            batch.append(member)
            if len(batch) < 5:
                continue

            await send_member_batch(chat_id, batch, prefix)
            sent += len(batch)
            batch.clear()
            await asyncio.sleep(1.5)

        if not stop_event.is_set() and batch:
            await send_member_batch(chat_id, batch, prefix)
            sent += len(batch)

        if stop_event.is_set():
            await bot.send_message(chat_id, f"⛔ Mention ရပ်လိုက်ပါပြီ။ {sent} ယောက်အထိ လုပ်ပြီးပါပြီ။")
        else:
            await bot.send_message(chat_id, f"✅ Group member အားလုံးကို mention လုပ်ပြီးပါပြီ။ စုစုပေါင်း {sent} ယောက်။")

    except Exception as error:
        log.exception("/all failed in chat %s", chat_id)
        await bot.send_message(
            chat_id,
            "❌ Member list ရယူရာမှာ error ဖြစ်ပါတယ်။\n\n"
            "User Account Session က ဒီ Group ထဲမှာရှိပြီးသားဖြစ်ရမယ်။\n"
            f"`{error}`",
        )
    finally:
        mention_tasks.pop(chat_id, None)
        mention_stop_events.pop(chat_id, None)


@bot.on_message(filters.command("all"))
async def all_handler(_, message):
    chat_id = message.chat.id
    user_id = message.from_user.id if message.from_user else 0

    if message.chat.type not in {"group", "supergroup"}:
        await message.reply_text("❌ `/all` ကို Group ထဲမှာပဲ အသုံးပြုနိုင်ပါတယ်။")
        return

    if not await is_admin_or_owner(bot, chat_id, user_id):
        await message.reply_text("❌ Group Admin / Owner သာ `/all` အသုံးပြုနိုင်ပါတယ်။")
        return

    if not await is_bot_admin(chat_id):
        await message.reply_text("❌ Bot ကို ဒီ Group မှာ Admin အရင်ပေးပါ။")
        return

    # The user session must also be a group member because it is the account
    # that reads the full participant list via MTProto.
    try:
        me = await assistant.get_me()
        session_member = await assistant.get_chat_member(chat_id, me.id)
        session_status = str(session_member.status).lower()
        if session_status in {"left", "kicked", "chatmemberstatus.left", "chatmemberstatus.banned"}:
            await message.reply_text(
                "❌ User Account Session က ဒီ Group ထဲမှာ မရှိပါ။\n"
                "Session သုံးထားတဲ့ Telegram account ကို Group ထဲအရင်ဝင်ပါ။"
            )
            return
    except Exception as error:
        await message.reply_text(
            "❌ User Account Session နဲ့ Group member list မရယူနိုင်ပါ။\n"
            "Session account ကို Group ထဲထည့်ထားတာ စစ်ပါ။\n\n"
            f"`{error}`"
        )
        return

    if chat_id in mention_tasks and not mention_tasks[chat_id].done():
        await message.reply_text("⚠️ ဒီ Group မှာ `/all` လုပ်နေပြီးသားပါ။ ရပ်ချင်ရင် `/stop` ပို့ပါ။")
        return

    mention_stop_events[chat_id] = asyncio.Event()

    extra = " ".join(message.command[1:]).strip()
    if len(extra) > 1000:
        extra = extra[:1000]

    # Include the optional /all text in every 5-member batch.
    mention_tasks[chat_id] = asyncio.create_task(
        run_all_mentions(chat_id, mention_stop_events[chat_id], extra)
    )
    task = mention_tasks[chat_id]

    if extra:
        await message.reply_text(f"📣 Mention စတင်ပါပြီ။\n📝 {extra}\n\n👥 5 ယောက်စီ လုပ်သွားပါမယ်။")
    else:
        await message.reply_text("📣 Mention စတင်ပါပြီ။\n\n👥 5 ယောက်စီနဲ့ member အားလုံးကို လုပ်သွားပါမယ်။")


@bot.on_message(filters.command("stop"))
async def mention_stop_handler(_, message):
    chat_id = message.chat.id
    user_id = message.from_user.id if message.from_user else 0

    if message.chat.type not in {"group", "supergroup"}:
        return

    if not await is_admin_or_owner(bot, chat_id, user_id):
        await message.reply_text("❌ Group Admin / Owner သာ `/stop` အသုံးပြုနိုင်ပါတယ်။")
        return

    stop_event = mention_stop_events.get(chat_id)
    task = mention_tasks.get(chat_id)
    if not stop_event or not task or task.done():
        await message.reply_text("ℹ️ လက်ရှိ mention လုပ်နေတဲ့ process မရှိပါ။")
        return

    stop_event.set()
    await message.reply_text("⏹️ Mention process ကို ရပ်ဖို့ signal ပေးပြီးပါပြီ။")


async def youtube_search_and_download(query: str):
    """
    Search YouTube when query is a song name, then download best audio.
    If query is already a YouTube URL, download that URL.
    """

    def work():
        target = query.strip()

        if not target.startswith(("http://", "https://")):
            target = f"ytsearch1:{target}"

        search_options = {
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "extract_flat": True,
        }

        with yt_dlp.YoutubeDL(search_options) as ydl:
            info = ydl.extract_info(
                target,
                download=False,
            )

        if not info:
            raise RuntimeError("YouTube result not found.")

        if "entries" in info:
            entries = [
                item for item in info["entries"]
                if item
            ]

            if not entries:
                raise RuntimeError("YouTube result not found.")

            info = entries[0]

        webpage_url = info.get("webpage_url")

        if not webpage_url:
            webpage_url = info.get("url")

        if not webpage_url:
            raise RuntimeError("YouTube URL could not be resolved.")

        title = info.get("title") or query
        video_id = info.get("id") or str(abs(hash(webpage_url)))

        output_template = str(
            DOWNLOAD_DIR / f"{video_id}.%(ext)s"
        )

        download_options = {
            "format": "bestaudio/best",
            "outtmpl": output_template,
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "192",
                }
            ],
        }

        with yt_dlp.YoutubeDL(download_options) as ydl:
            ydl.extract_info(
                webpage_url,
                download=True,
            )

        possible_files = list(
            DOWNLOAD_DIR.glob(f"{video_id}.*")
        )

        possible_files = [
            path
            for path in possible_files
            if path.suffix.lower() not in {
                ".part",
                ".ytdl",
            }
        ]

        if not possible_files:
            raise RuntimeError("Audio download failed.")

        return (
            str(possible_files[0]),
            title,
            webpage_url,
        )

    return await asyncio.to_thread(work)


async def play_next(chat_id: int):
    async with locks[chat_id]:

        if chat_id in current:
            return

        if not queues[chat_id]:
            return

        item = queues[chat_id].pop(0)
        current[chat_id] = item

        try:
            await calls.play(
                chat_id,
                MediaStream(
                    item["file"],
                    video_flags=MediaStream.Flags.IGNORE,
                ),
            )

            await bot.send_message(
                chat_id,
                "▶️ **Now Playing**\n\n"
                f"🎵 {item['title']}",
            )

        except Exception as error:
            current.pop(chat_id, None)

            try:
                if os.path.exists(item["file"]):
                    os.remove(item["file"])
            except Exception:
                pass

            await bot.send_message(
                chat_id,
                "❌ Voice Chat playback failed.\n\n"
                f"`{error}`",
            )

            # Try the next queued song.
            await play_next(chat_id)


@calls.on_update(call_filters.stream_end())
async def stream_end_handler(
    _: PyTgCalls,
    update: StreamEnded,
):
    chat_id = update.chat_id

    item = current.pop(chat_id, None)

    if item:
        try:
            if os.path.exists(item["file"]):
                os.remove(item["file"])
        except Exception:
            pass

    # Automatically play the next queued song.
    await play_next(chat_id)


@bot.on_message(filters.command("start"))
async def start_handler(_, message):

    if (
        message.chat.type == "private"
        and not await required_group_ok(
            message.from_user.id
        )
    ):
        await message.reply_text(
            "🔒 **Join to Group**\n\n"
            "ဒီ Bot ကိုအသုံးပြုဖို့ သတ်မှတ်ထားတဲ့ "
            "Group ထဲ အရင် Join လုပ်ပါ။\n\n"
            "Join ပြီးရင် `/start` ပြန်ပို့ပါ။"
        )
        return

    await message.reply_text(
        "🎵 **Pro Music Bot**\n\n"
        "Group Voice Chat ထဲမှာ သီချင်းဖွင့်နိုင်ပါတယ်။\n\n"
        "▶️ `/play Alan Walker Faded`\n"
        "📋 `/queue`\n"
        "⏭ `/skip`\n"
        "⏭ `/skip 2`\n"
        "❓ `/help`"
    )


@bot.on_message(filters.command("help"))
async def help_handler(_, message):

    await message.reply_text(
        "📚 **Pro Music Bot Commands**\n\n"
        "🎵 `/play song name`\n"
        "YouTube မှ ရှာပြီး Download လုပ်ကာ "
        "Voice Chat ထဲဖွင့်ပါမယ်။\n\n"
        "📋 `/queue`\n"
        "Queue ကြည့်ပါ။\n\n"
        "⏭ `/skip`\n"
        "လက်ရှိသီချင်းကျော်ပြီး နောက်တစ်ပုဒ်ဖွင့်ပါမယ်။\n\n"
        "⏭ `/skip 2`\n"
        "လက်ရှိ + နောက် ၁ ပုဒ်ကို ကျော်ပါမယ်။\n\n"
        "🔐 `/auth USER_ID`\n"
        "Music Control ခွင့်ပေးပါ။\n\n"
        "🚫 `/unauth USER_ID`\n"
        "Music Control ခွင့်ပြန်ဖယ်ပါ။"
    )


@bot.on_message(filters.command("auth"))
async def auth_handler(_, message):

    if not await is_admin_or_owner(
        bot,
        message.chat.id,
        message.from_user.id,
    ):
        await message.reply_text(
            "❌ Group Admin / Owner သာ အသုံးပြုနိုင်ပါတယ်။"
        )
        return

    if len(message.command) < 2:
        await message.reply_text(
            "အသုံးပြုပုံ:\n"
            "`/auth USER_ID`"
        )
        return

    try:
        target_id = int(
            message.command[1]
        )
    except ValueError:
        await message.reply_text(
            "❌ USER_ID မမှန်ပါ။"
        )
        return

    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO authorized_users (
                chat_id,
                user_id
            )
            VALUES ($1, $2)
            ON CONFLICT DO NOTHING
            """,
            message.chat.id,
            target_id,
        )

    await message.reply_text(
        f"✅ `{target_id}` ကို "
        "Music Control ပေးပြီးပါပြီ။"
    )


@bot.on_message(filters.command("unauth"))
async def unauth_handler(_, message):

    if not await is_admin_or_owner(
        bot,
        message.chat.id,
        message.from_user.id,
    ):
        await message.reply_text(
            "❌ Group Admin / Owner သာ အသုံးပြုနိုင်ပါတယ်။"
        )
        return

    if len(message.command) < 2:
        await message.reply_text(
            "အသုံးပြုပုံ:\n"
            "`/unauth USER_ID`"
        )
        return

    try:
        target_id = int(
            message.command[1]
        )
    except ValueError:
        await message.reply_text(
            "❌ USER_ID မမှန်ပါ။"
        )
        return

    async with db.acquire() as conn:
        await conn.execute(
            """
            DELETE FROM authorized_users
            WHERE chat_id=$1
              AND user_id=$2
            """,
            message.chat.id,
            target_id,
        )

    await message.reply_text(
        f"✅ `{target_id}` ရဲ့ "
        "Music Control ကို ဖယ်ပြီးပါပြီ။"
    )


@bot.on_message(filters.command("play"))
async def play_handler(_, message):

    chat_id = message.chat.id
    user_id = message.from_user.id

    if message.chat.type == "private":
        await message.reply_text(
            "❌ `/play` ကို Group ထဲမှာပဲ "
            "အသုံးပြုပါ။"
        )
        return

    if not await can_control(
        bot,
        chat_id,
        user_id,
    ):
        await message.reply_text(
            "❌ Music Control ခွင့်မရှိပါ။\n"
            "Group Admin ဖြစ်ရမယ် သို့မဟုတ် "
            "`/auth USER_ID` နဲ့ ခွင့်ပြုထားရပါမယ်။"
        )
        return

    if len(message.command) < 2:
        await message.reply_text(
            "အသုံးပြုပုံ:\n"
            "`/play song name`"
        )
        return

    query = " ".join(
        message.command[1:]
    ).strip()

    status = await message.reply_text(
        f"🔎 YouTube မှ **{query}** ကို "
        "ရှာနေပါတယ်..."
    )

    try:
        file_path, title, url = (
            await youtube_search_and_download(
                query
            )
        )
    except Exception as error:
        await status.edit_text(
            "❌ YouTube Download မအောင်မြင်ပါ။\n\n"
            f"`{error}`"
        )
        return

    item = {
        "title": title,
        "file": file_path,
        "url": url,
        "requested_by": user_id,
    }

    # If a song is already playing, add to queue.
    if chat_id in current:

        queues[chat_id].append(item)

        position = len(
            queues[chat_id]
        )

        await status.edit_text(
            "📋 **Added to Queue**\n\n"
            f"🎵 {title}\n"
            f"📍 Position: {position}"
        )
        return

    # Nothing is playing, so play immediately.
    current[chat_id] = item

    try:
        await calls.play(
            chat_id,
            MediaStream(
                file_path,
                video_flags=MediaStream.Flags.IGNORE,
            ),
        )

        await status.edit_text(
            "▶️ **Now Playing**\n\n"
            f"🎵 {title}"
        )

    except Exception as error:

        current.pop(chat_id, None)

        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass

        await status.edit_text(
            "❌ Voice Chat ထဲ မဖွင့်နိုင်ပါ။\n\n"
            "အောက်က ၃ ခုကို စစ်ပါ။\n"
            "1. Group မှာ Voice Chat ဖွင့်ထားပါ။\n"
            "2. Assistant account ကို Group ထဲထည့်ထားပါ။\n"
            "3. Assistant account ကို Voice Chat "
            "ပြောခွင့်ရှိအောင် စစ်ပါ။\n\n"
            f"`{error}`"
        )


@bot.on_message(filters.command("queue"))
async def queue_handler(_, message):

    chat_id = message.chat.id
    items = queues[chat_id]

    lines = [
        "📋 **Current Queue**"
    ]

    if chat_id in current:
        lines.append(
            "\n▶️ Now: "
            f"{current[chat_id]['title']}"
        )

    if not items:
        lines.append(
            "\nQueue ထဲမှာ "
            "နောက်ထပ်သီချင်း မရှိပါ။"
        )
    else:
        lines.append("")

        for index, item in enumerate(
            items,
            start=1,
        ):
            lines.append(
                f"{index}. {item['title']}"
            )

    await message.reply_text(
        "\n".join(lines)
    )


@bot.on_message(filters.command("skip"))
async def skip_handler(_, message):

    chat_id = message.chat.id
    user_id = message.from_user.id

    if not await can_control(
        bot,
        chat_id,
        user_id,
    ):
        await message.reply_text(
            "❌ Music Control ခွင့်မရှိပါ။"
        )
        return

    count = 1

    if len(message.command) >= 2:
        try:
            count = max(
                1,
                int(message.command[1]),
            )
        except ValueError:
            count = 1

    if (
        chat_id not in current
        and not queues[chat_id]
    ):
        await message.reply_text(
            "📋 Queue မရှိပါ။"
        )
        return

    # /skip N means skip N tracks, with
    # the currently playing track counted as 1.
    old_current = current.pop(
        chat_id,
        None,
    )

    if old_current:
        try:
            await calls.leave_call(
                chat_id
            )
        except Exception:
            pass

        try:
            if os.path.exists(
                old_current["file"]
            ):
                os.remove(
                    old_current["file"]
                )
        except Exception:
            pass

        count -= 1

    skipped_queued = 0

    while (
        count > 0
        and queues[chat_id]
    ):
        item = queues[
            chat_id
        ].pop(0)

        skipped_queued += 1
        count -= 1

        try:
            if os.path.exists(
                item["file"]
            ):
                os.remove(
                    item["file"]
                )
        except Exception:
            pass

    await message.reply_text(
        "⏭ **Skip လုပ်ပြီးပါပြီ။**"
    )

    await play_next(
        chat_id
    )


async def main():

    await init_db()

    if not SESSION_STRING:
        raise RuntimeError(
            "SESSION_STRING မရှိပါ။ "
            "Codespaces Environment Variable ကို စစ်ပါ။"
        )

    # PyTgCalls starts the assistant MTProto client.
    await calls.start()

    # Start the command bot.
    await bot.start()

    log.info(
        "Pro Music Bot + Assistant + PyTgCalls started"
    )

    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
